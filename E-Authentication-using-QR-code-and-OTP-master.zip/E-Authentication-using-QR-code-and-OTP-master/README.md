# E-Authentication-using-QR-code-and-OTP

Run the project by following steps:
First of all you need to have software in your system to run it. (mySQL, php, any editor (like brackets), etc) .
Then put all those files in a folder and run Simple registration.html file.
This is how you can run the project.

This project is all about the authentication of the user if he/she has already registered their data in the database.
This project focuses on user authentication by verifying if their data is already registered in the database. Users with valid credentials can log in to their profiles, while others are denied access. Additionally, it implements a two-factor authentication system, requiring users to enter an OTP and scan a QR code.
